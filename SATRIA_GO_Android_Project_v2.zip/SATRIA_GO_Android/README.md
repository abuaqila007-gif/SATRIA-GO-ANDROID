# SATRIA GO Android

Project Android WebView untuk membuka https://satria-go.pages.dev/ sebagai aplikasi Android.

## Identitas
- Nama aplikasi: SATRIA GO
- Application ID: `id.satria.go`
- Minimum Android: Android 6.0 (API 23)
- Target SDK: 35

## Cara membangun APK
1. Buka folder project ini menggunakan Android Studio versi terbaru.
2. Pastikan Android SDK Platform 35 terpasang.
3. Tunggu proses Gradle Sync selesai.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug dapat ditemukan di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Aplikasi memuat website SATRIA GO secara online; koneksi internet diperlukan.
- Data dan backend tetap menggunakan sistem website/Supabase yang sudah ada.
- Ini adalah project sumber Android, bukan file APK yang sudah dikompilasi.
- Sebelum rilis Play Store, lakukan pengujian perangkat, kebijakan privasi, ikon final, dan konfigurasi signing.

## Build otomatis melalui GitHub (tanpa Android Studio di HP)
1. Buat repository GitHub baru bernama `satria-go-android`.
2. Upload seluruh isi ZIP project ini ke repository, termasuk folder tersembunyi `.github`.
3. Buka tab **Actions** pada repository dan pilih workflow **Build SATRIA GO APK**.
4. Setelah proses selesai, buka hasil run dan unduh artifact **SATRIA-GO-debug-APK**.
5. Ekstrak ZIP artifact, lalu instal `app-debug.apk` di perangkat Android untuk pengujian.

Workflow juga berjalan otomatis setiap ada push ke branch `main`.
